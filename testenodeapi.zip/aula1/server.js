import express from 'express'; // "type": "module" deve estar no package.json
import mysql from 'mysql2'; // Importando o mysql2 da pasta node_modules

// Criando a conexão com o banco de dados
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'testenodeapi',
});

// Testando a conexão com o banco de dados
connection.connect((err) => {
    if (err) {
        console.error('Erro ao conectar ao MySQL:', err.message);
    } else {
        console.log('Conexão com MySQL bem-sucedida!');
    }
});

const app = express();
app.use(express.json()); // Middleware para interpretar JSON

// Rota POST para inserir usuários no banco de dados
app.post('/usuarios', (req, res) => {
    const { name, email, age } = req.body;

    // Verifica se todos os campos necessários foram enviados
    if (!name || !email || !age) {
        return res.status(400).json({ error: 'Todos os campos (name, email, age) são obrigatórios.' });
    }

    // Query para inserir dados no banco
    connection.query(
        'INSERT INTO user (name, email, age) VALUES (?, ?, ?)', // Alterado para "user"
        [name, email, age],
        (error, results) => {
            if (error) {
                console.error('Erro ao inserir dados:', error); // Log do erro
                return res.status(500).json({ error: 'Erro ao inserir dados' });
            }
            console.log('Resultado da query:', results); // Log do resultado
            res.status(201).json({ message: 'Dados inseridos com sucesso' });
        }
    );
});

app.put('/usuarios/:id_user', (req, res) => {
    const { id_user } = req.params; // Obtém o ID do usuário a partir dos parâmetros da URL
    const { name, email, age } = req.body; // Obtém os dados do corpo da requisição

    // Verifica se todos os campos necessários foram enviados
    if (!name || !email || !age) {
        return res.status(400).json({ error: 'Todos os campos (name, email, age) são obrigatórios.' });
    }

    // Query para atualizar os dados no banco
    connection.query(
        'UPDATE user SET name = ?, email = ?, age = ? WHERE id_user = ?', // Atualiza os dados do usuário
        [name, email, age, id_user], // Passa os valores para a query
        (error, results) => {
            if (error) {
                console.error('Erro ao atualizar dados:', error); // Log do erro
                return res.status(500).json({ error: 'Erro ao atualizar dados' });
            }

            // Verifica se algum registro foi afetado
            if (results.affectedRows === 0) {
                return res.status(404).json({ error: 'Usuário não encontrado' });
            }

            console.log('Dados atualizados com sucesso:', results); // Log do resultado
            res.status(200).json({ message: 'Dados atualizados com sucesso' });
        }
    );
});

// Rota GET para listar usuários (exemplo básico)
app.get('/usuarios', (req, res) => {
    connection.query('SELECT * FROM user', (error, results) => {
        if (error) {
            console.error('Erro ao buscar dados:', error);
            return res.status(500).json({ error: 'Erro ao buscar dados' });
        }
        res.status(200).json(results);
    });
});

// Iniciando o servidor na porta 3300
app.listen(3300, () => {
    console.log('Servidor rodando na porta 3300');
});