import express from 'express'; // "type": "module" deve estar no package.json
import mysql from 'mysql2'; // Importando o mysql2 da pasta node_modules

// Criando a conexão com o banco de dados
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'testenodeapi',
});

// Testando a conexão com o banco de dados
connection.connect((err) => {
    if (err) {
        console.error('Erro ao conectar ao MySQL:', err.message);
    } else {
        console.log('Conexão com MySQL bem-sucedida!');
    }
});

const app = express();
app.use(express.json()); // Middleware para interpretar JSON

// Rota POST para inserir usuários no banco de dados
app.post('/usuarios', (req, res) => {
    const { name, email, age } = req.body;

    // Verifica se todos os campos necessários foram enviados
    if (!name || !email || !age) {
        return res.status(400).json({ error: 'Todos os campos (name, email, age) são obrigatórios.' });
    }

    // Query para inserir dados no banco
    connection.query(
        'INSERT INTO user (name, email, age) VALUES (?, ?, ?)', // Alterado para "user"
        [name, email, age],
        (error, results) => {
            if (error) {
                console.error('Erro ao inserir dados:', error); // Log do erro
                return res.status(500).json({ error: 'Erro ao inserir dados' });
            }
            console.log('Resultado da query:', results); // Log do resultado
            res.status(201).json({ message: 'Dados inseridos com sucesso' });
        }
    );
});

// Rota GET para listar usuários (exemplo básico)
app.get('/usuarios', (req, res) => {
    connection.query('SELECT * FROM user', (error, results) => {
        if (error) {
            console.error('Erro ao buscar dados:', error);
            return res.status(500).json({ error: 'Erro ao buscar dados' });
        }
        res.status(200).json(results);
    });
});

// Iniciando o servidor na porta 3300
app.listen(3300, () => {
    console.log('Servidor rodando na porta 3300');
});